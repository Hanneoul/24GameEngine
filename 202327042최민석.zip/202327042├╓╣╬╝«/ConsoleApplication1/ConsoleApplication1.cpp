﻿#pragma comment(lib, "Opengl32.lib")

#include <iostream>
#include <GLFW/glfw3.h>
#include <cmath>

float scale = 1.0f;
float cameraPosX = 0.0f;
float cameraPosY = 0.0f;

void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
    float speed = 0.1f;
    if (key == GLFW_KEY_UP && action == GLFW_PRESS)
        scale += 0.1f;
    else if (key == GLFW_KEY_DOWN && action == GLFW_PRESS)
        scale -= 0.1f;

    scale = std::max(scale, 0.1f); // 최소 축소량은 0.1로 제한

    if (key == GLFW_KEY_RIGHT && action == GLFW_PRESS)
        cameraPosX += speed;
    else if (key == GLFW_KEY_LEFT && action == GLFW_PRESS)
        cameraPosX -= speed;
}

void cursor_position_callback(GLFWwindow* window, double xpos, double ypos)
{
    static bool rightButtonDown = false;
    static double lastX = 0.0;
    static double lastY = 0.0;

    if (glfwGetMouseButton(window, GLFW_MOUSE_BUTTON_RIGHT) == GLFW_PRESS)
    {
        if (!rightButtonDown)
        {
            rightButtonDown = true;
            lastX = xpos;
            lastY = ypos;
        }

        float dx = xpos - lastX;
        float dy = ypos - lastY;

        scale += dy * 0.01f;

        scale = std::max(scale, 0.1f); // 최소 축소량은 0.1로 제한

        lastX = xpos;
        lastY = ypos;
    }
    else
    {
        rightButtonDown = false;
    }
}

int render()
{
    glBegin(GL_TRIANGLES);

    //삼각형 1개
    glColor3f(1.0f, 1.0f, 1.0f);
    glVertex2f(0.0f, 0.9f);

    glColor3f(1.0f, 1.0f, 1.0f);
    glVertex2f(-0.5f, 0.0f);

    glColor3f(1.0f, 1.0f, 1.0f);
    glVertex2f(0.5f, 0.0f);

    //삼각형 2개
    glColor3f(1.0f, 1.0f, 1.0f);
    glVertex2f(0.5f, 0.0f);

    glColor3f(1.0f, 1.0f, 1.0f);
    glVertex2f(-1.0f, 0.0f);

    glColor3f(1.0f, 1.0f, 1.0f);
    glVertex2f(1.0f, -1.0f);

    //삼각형 3개
    glColor3f(1.0f, 1.0f, 1.0f);
    glVertex2f(1.0f, 0.0f);

    glColor3f(1.0f, 1.0f, 1.0f);
    glVertex2f(-0.5f, 0.0f);

    glColor3f(1.0f, 1.0f, 1.0f);
    glVertex2f(-1.0f, -1.0f);

    glEnd();
    return 0;
}

int main(void)
{
    GLFWwindow* window;

    /* Initialize the library */
    if (!glfwInit())
        return -1;

    /* Create a windowed mode window and its OpenGL context */
    window = glfwCreateWindow(640, 480, "Hello World", NULL, NULL);
    if (!window)
    {
        glfwTerminate();
        return -1;
    }
    /* Make the window's context current */
    glfwMakeContextCurrent(window);

    /* Set the callback functions */
    glfwSetKeyCallback(window, key_callback);
    glfwSetCursorPosCallback(window, cursor_position_callback);

    /* Loop until the user closes the window */
    while (!glfwWindowShouldClose(window))
    {
        /* Poll for and process events */
        glfwPollEvents();

        /* Render here */
        glClearColor(1.0f, 0.0f, 1.0f, 1.0f);
        glClear(GL_COLOR_BUFFER_BIT);

        glMatrixMode(GL_MODELVIEW);
        glLoadIdentity();
        glScalef(scale, scale, 1.0f);
        glTranslatef(-cameraPosX, -cameraPosY, 0.0f);

        render();

        /* Swap front and back buffers */
        glfwSwapBuffers(window);
    }

    glfwTerminate();
    return 0;
}